import React, { Component } from "react";

const Footer = props => {
  return (
    <footer>
      <p className="footer-links">
        &copy; copyright
	  </p>
    </footer>
  );
};

export default Footer;
